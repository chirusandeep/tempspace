package in.com.stepdefinition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.junit.Assert;

import in.com.exceptions.ServerNotRunningException;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetOrderStepDefinition {


	public static RequestSpecification request;
	public static Response response;
	Helper objrepo = new Helper();
	public Scenario scenario;
	public static final Logger logger = LogManager.getLogger(GetOrderStepDefinition.class.getName());

	@Before
	public void before(Scenario scenario) {
		this.scenario = scenario;
	}

	@Given("I get the order details")
	public void i_get_the_order_details() {
		response = objrepo.getResponse();
		logger.info(response.asPrettyString());
	}

	@When("I invoke the get order service")
	public void i_invoke_the_get_order_service() {
		request = objrepo.getRequest();
		response = objrepo.getResponse();
		request.header("Authorization", "Bearer " + objrepo.getToken());
		response = request.get("http://localhost:8088/orders/" + objrepo.getOrderId());
		scenario.log("Get order details" + objrepo.getOrderId());
		scenario.log("Get order details response" + response.prettyPrint());
		logger.info(response.asPrettyString());
		objrepo.setResponse(response);

	}

}
