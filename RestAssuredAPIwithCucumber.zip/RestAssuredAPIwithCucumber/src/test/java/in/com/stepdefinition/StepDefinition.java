//package in.com.stepdefinition;
//
//import io.cucumber.java.Before;
//import io.cucumber.java.Scenario;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import io.restassured.RestAssured;
//import io.restassured.response.Response;
//import io.restassured.specification.RequestSpecification;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;
//import org.json.simple.JSONObject;
//import org.junit.Assert;
//
//import in.com.exceptions.ServerNotRunningException;
//import io.cucumber.datatable.DataTable;
//
//public class StepDefinition {
//	
//	public static String url, username, password, latitude, longitude;
//	public static RequestSpecification request;
//	public static Response response;
//	public static String token;
//	public static Map<String, Object> orderMap;
//	public static Map<String, Double> pickupMap, deliveryMap;
//	private static int orderId;
//	private Scenario scenario;
//	public static final Logger logger = LogManager.getLogger(StepDefinition.class.getName());
//
//	@Before
//	public void before(Scenario scenario) {
//		this.scenario = scenario;
//	}
//
//	@Given("I have the end point URL")
//	public void i_have_the_end_point_url(DataTable dataTable) {
//		Map<String, String> map = dataTable.asMap();
//		url = map.get("URL");
//		PropertyConfigurator.configure("log4j.properties");
//	}
//
//	@Given("I provide authentication credentials")
//	public void i_provide_authentication_credentials(DataTable dataTable) {
//		Map<String, String> map = dataTable.asMap();
//		username = map.get("username");
//		password = map.get("password");
//
//	}
//
//	@Given("I get the order authorization token")
//	public void i_get_the_order_authorization_token() throws ServerNotRunningException {
//		logger.info("request call made for auth/login.");
//		RestAssured.baseURI = url;
//		request = RestAssured.given();
//		request.header("Content-type", "application/json");
//		Map<String, String> map = new HashMap<String, String>();
//		map.put("username", username);
//		map.put("password", password);
//		JSONObject jsonformat = new JSONObject(map);
//		request.body(jsonformat);
//		try {
//			response = request.post("/auth/login");
//		} catch (Exception e) {
//			scenario.log("exception");
//			throw new ServerNotRunningException("created Exception ");
//		}
//
//		int statusCode = response.getStatusCode();
//		logger.info(statusCode);
//
//	}
//
//	@Given("I use the authorization token")
//	public void i_use_the_authorization_token() {
//		token = response.jsonPath().get("token");
//		logger.info(token);
//		scenario.log("token generated is " + token);
//
//	}
//
//	@Given("I create pickup location")
//	public void i_create_pickup_location(DataTable dataTable) {
//		pickupMap = dataTable.asMap(String.class, Double.class);
//		System.out.println(pickupMap);
//
//	}
//
//	@Given("I create delivery Location")
//	public void i_create_delivery_location(DataTable dataTable) {
//		deliveryMap = dataTable.asMap(String.class, Double.class);
//		System.out.println(deliveryMap);
//	}
//
//	@Given("I create the order details")
//	public void i_create_the_order_details(DataTable dataTable) {
//		orderMap = dataTable.asMap(String.class, Object.class);
//		Map<String, Object> finalMap = new HashMap<String, Object>(orderMap);
//		finalMap.put("pickup", pickupMap);
//		finalMap.put("delivery", deliveryMap);
//		scenario.log("Details to create order " + finalMap);
//		request.header("Authorization", "Bearer " + token);
//		logger.info(finalMap);
//		JSONObject json = new JSONObject(finalMap);
//		request.body(json);
//		System.out.println(finalMap);
//	}
//
//	@When("I invoke the create order service")
//	public void i_invoke_the_create_order_service() {
//		response = request.post("http://localhost:8088/orders");
//		scenario.log("Details to create order " + response.prettyPrint());
//	}
//
//	@Then("I validate the response {string} status code")
//	public void i_validate_the_response_status_code(String string) {
//		int statusCode = response.getStatusCode();
//		logger.info("Got Response status code as " + statusCode);
//
//	}
//
//	@Then("I validate the response values")
//	public void i_validate_the_response_values() {
//		orderId = response.jsonPath().getInt("id");
//
//		logger.info(orderId);
//	}
//
//	@Given("I get the order details")
//	public void i_get_the_order_details() {
//		logger.info(response.asPrettyString());
//	}
//
//	@When("I invoke the get order service")
//	public void i_invoke_the_get_order_service() {
//		request.header("Authorization", "Bearer " + token);
//		response = request.get("http://localhost:8088/orders/" + orderId);
//		scenario.log("Get order details" + orderId);
//		scenario.log("Get order details response" + response.prettyPrint());
//		logger.info(response.asPrettyString());
//
//	}
//
//	@Then("I validate the response status code <code>")
//	public void i_validate_the_response_status_code_code(DataTable dataTable) {
//		List<String> list = dataTable.asList();
//		// list.get(0);
//		int actualStatusCode = response.getStatusCode();
//		int expectedStatuscode = Integer.valueOf(list.get(0));
//		Assert.assertEquals(expectedStatuscode, actualStatusCode);
//		logger.info("Got Response status code as " + actualStatusCode);
//	}
//
//}
