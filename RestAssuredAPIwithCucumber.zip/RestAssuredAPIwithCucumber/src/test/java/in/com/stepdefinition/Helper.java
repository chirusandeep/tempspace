package in.com.stepdefinition;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Helper {

	public static String token;
	public static int orderId;
	public static Response response;
	public static RequestSpecification request;
	
	public RequestSpecification getRequest() {
		return request;
	}

	public void setRequest(RequestSpecification request) {
		Helper.request = request;
	}

	public Response getResponse() {
		return response;
	}

	public void setResponse(Response response) {
		Helper.response = response;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		Helper.token = token;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		Helper.orderId = orderId;
	}

}
