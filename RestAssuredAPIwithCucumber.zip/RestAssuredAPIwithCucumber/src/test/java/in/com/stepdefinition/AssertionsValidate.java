package in.com.stepdefinition;

import org.junit.Assert;

import io.restassured.path.json.JsonPath;

public class AssertionsValidate {

	public static void getOrderValidate(JsonPath response, int orderId) {
		Assert.assertEquals(response.getInt("id"), 0);
		Assert.assertEquals(response.getString("description"), "Gulab Jamoon");
		Assert.assertEquals(response.getBoolean("food"), true);
		Assert.assertEquals(response.getDouble("pickup.latitude"), 12.12);
		Assert.assertEquals(response.getDouble("pickup.longitude"), 13.13);
		Assert.assertEquals(response.getDouble("delivery.latitude"), 34.0);
		Assert.assertEquals(response.getDouble("delivery.longitude"), 36.2);
	}

	public static void createOrderValidate(String contentType,int statusCode) {
		Assert.assertEquals(contentType, "application/json;charset=UTF-8");

		Assert.assertEquals(statusCode, 201);
	}
	
	public static void tokenValidate(int statusCode) {
		Assert.assertEquals(statusCode, 200);
	}
}
