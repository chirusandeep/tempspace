package in.com.exceptions;

public class ServerNotRunningException extends Exception{

	public ServerNotRunningException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServerNotRunningException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ServerNotRunningException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ServerNotRunningException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ServerNotRunningException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}


	
	

}
